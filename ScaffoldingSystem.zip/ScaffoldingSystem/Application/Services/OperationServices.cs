using ScaffoldingSystem.Application.DTOs;
using ScaffoldingSystem.Application.Interfaces;
using ScaffoldingSystem.Domain.Entities;
using ScaffoldingSystem.Domain.Enums;
using ScaffoldingSystem.Domain.Interfaces;

namespace ScaffoldingSystem.Application.Services;

// ── SCAFFOLDING SERVICE ───────────────────────────────────────────────────────
public class ScaffoldingService : IScaffoldingService
{
    private readonly IScaffoldingRepository _repo;
    public ScaffoldingService(IScaffoldingRepository repo) => _repo = repo;

    public async Task<ScaffoldingDto> CreateAsync(CreateScaffoldingRequest request)
    {
        if (await _repo.GetByCodeAsync(request.Code) is not null)
            throw new InvalidOperationException($"Ya existe un andamio con el código '{request.Code}'.");

        var s = new Scaffolding
        {
            Code = request.Code.ToUpper(),
            Description = request.Description,
            Type = request.Type,
            HeightMeters = request.HeightMeters,
            WeightKg = request.WeightKg,
            Location = request.Location,
            Notes = request.Notes
        };
        await _repo.AddAsync(s);
        return Map(s);
    }

    public async Task<ScaffoldingDto?> GetByIdAsync(int id)
    {
        var s = await _repo.GetByIdAsync(id);
        return s is null ? null : Map(s);
    }

    public async Task<IEnumerable<ScaffoldingDto>> GetAllAsync()
        => (await _repo.GetAllAsync()).Select(Map);

    public async Task<IEnumerable<ScaffoldingDto>> GetAvailableAsync()
        => (await _repo.GetAvailableAsync()).Select(Map);

    public async Task<ScaffoldingDto> UpdateAsync(int id, UpdateScaffoldingRequest request)
    {
        var s = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Andamio ID {id} no encontrado.");
        s.Description = request.Description;
        s.Status = request.Status;
        s.Location = request.Location;
        s.Notes = request.Notes;
        s.UpdatedAt = DateTime.UtcNow;
        await _repo.UpdateAsync(s);
        return Map(s);
    }

    public async Task DeleteAsync(int id)
    {
        if (!await _repo.ExistsAsync(id))
            throw new KeyNotFoundException($"Andamio ID {id} no encontrado.");
        await _repo.DeleteAsync(id);
    }

    private static ScaffoldingDto Map(Scaffolding s) => new(
        s.Id, s.Code, s.Description, s.Type.ToString(),
        s.Status.ToString(), s.HeightMeters, s.WeightKg, s.Location, s.Notes);
}

// ── RENTAL SERVICE ────────────────────────────────────────────────────────────
public class RentalService : IRentalService
{
    private readonly IRentalRepository _repo;
    private readonly IScaffoldingRepository _scaffoldingRepo;

    public RentalService(IRentalRepository repo, IScaffoldingRepository scaffoldingRepo)
    {
        _repo = repo;
        _scaffoldingRepo = scaffoldingRepo;
    }

    public async Task<RentalDto> CreateAsync(CreateRentalRequest request)
    {
        if (request.StartDate >= request.ExpectedEndDate)
            throw new ArgumentException("La fecha de inicio debe ser anterior a la fecha fin.");

        var rentalNumber = await _repo.GenerateRentalNumberAsync();

        var rental = new Rental
        {
            RentalNumber = rentalNumber,
            ClientUserId = request.ClientUserId,
            StartDate = request.StartDate,
            ExpectedEndDate = request.ExpectedEndDate,
            DeliveryAddress = request.DeliveryAddress,
            Observations = request.Observations,
            Items = request.Items.Select(i => new RentalItem
            {
                ScaffoldingId = i.ScaffoldingId,
                Quantity = i.Quantity,
                DailyRate = i.DailyRate
            }).ToList()
        };

        var days = (request.ExpectedEndDate - request.StartDate).Days;
        rental.TotalAmount = request.Items.Sum(i => i.DailyRate * i.Quantity * days);

        await _repo.AddAsync(rental);

        // Marcar andamios como alquilados
        foreach (var item in request.Items)
        {
            var scaffolding = await _scaffoldingRepo.GetByIdAsync(item.ScaffoldingId);
            if (scaffolding is not null)
            {
                scaffolding.Status = ScaffoldingStatus.Alquilado;
                await _scaffoldingRepo.UpdateAsync(scaffolding);
            }
        }

        return await GetByIdAsync(rental.Id) ?? throw new Exception("Error al recuperar el alquiler creado.");
    }

    public async Task<RentalDto?> GetByIdAsync(int id)
    {
        var r = await _repo.GetWithDetailsAsync(id);
        return r is null ? null : Map(r);
    }

    public async Task<IEnumerable<RentalDto>> GetAllAsync()
    {
        var rentals = await _repo.GetAllAsync();
        return rentals.Select(Map);
    }

    public async Task<IEnumerable<RentalDto>> GetByClientAsync(int clientUserId)
    {
        var rentals = await _repo.GetByClientAsync(clientUserId);
        return rentals.Select(Map);
    }

    public async Task<RentalDto> UpdateStatusAsync(int id, UpdateRentalStatusRequest request)
    {
        var r = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Alquiler ID {id} no encontrado.");
        r.Status = request.Status;
        r.Observations = request.Observations ?? r.Observations;
        if (request.Status == RentalStatus.Devuelto) r.ActualEndDate = DateTime.UtcNow;
        r.UpdatedAt = DateTime.UtcNow;
        await _repo.UpdateAsync(r);
        return Map(r);
    }

    private static RentalDto Map(Rental r) => new(
        r.Id, r.RentalNumber,
        r.Client?.FullName ?? $"Cliente #{r.ClientUserId}",
        r.StartDate, r.ExpectedEndDate, r.ActualEndDate,
        r.Status.ToString(), r.TotalAmount, r.DeliveryAddress,
        r.Items.Select(i => new RentalItemDto(
            i.ScaffoldingId, i.Scaffolding?.Code ?? $"AND-{i.ScaffoldingId}",
            i.Quantity, i.DailyRate)).ToList());
}

// ── DISPATCH SERVICE ──────────────────────────────────────────────────────────
public class DispatchService : IDispatchService
{
    private readonly IDispatchRepository _repo;
    private readonly IRentalRepository _rentalRepo;

    public DispatchService(IDispatchRepository repo, IRentalRepository rentalRepo)
    {
        _repo = repo;
        _rentalRepo = rentalRepo;
    }

    public async Task<DispatchDto> CreateAsync(CreateDispatchRequest request, int dispatchedByUserId)
    {
        var rental = await _rentalRepo.GetByIdAsync(request.RentalId)
            ?? throw new KeyNotFoundException($"Alquiler ID {request.RentalId} no encontrado.");

        if (rental.Status != RentalStatus.Aprobado)
            throw new InvalidOperationException("Solo se pueden despachar alquileres en estado 'Aprobado'.");

        var dispatch = new Dispatch
        {
            RentalId = request.RentalId,
            DispatchedByUserId = dispatchedByUserId,
            DispatchDate = DateTime.UtcNow,
            TransportPlate = request.TransportPlate.ToUpper(),
            DriverName = request.DriverName,
            GuideNumber = request.GuideNumber,
            Notes = request.Notes,
            Status = DispatchStatus.EnCamino
        };

        rental.Status = RentalStatus.Activo;
        await _rentalRepo.UpdateAsync(rental);
        await _repo.AddAsync(dispatch);
        return Map(dispatch, rental.RentalNumber);
    }

    public async Task<DispatchDto?> GetByIdAsync(int id)
    {
        var d = await _repo.GetByIdAsync(id);
        if (d is null) return null;
        var rental = await _rentalRepo.GetByIdAsync(d.RentalId);
        return Map(d, rental?.RentalNumber ?? "");
    }

    public async Task<IEnumerable<DispatchDto>> GetPendingAsync()
    {
        var dispatches = await _repo.GetPendingAsync();
        var result = new List<DispatchDto>();
        foreach (var d in dispatches)
        {
            var rental = await _rentalRepo.GetByIdAsync(d.RentalId);
            result.Add(Map(d, rental?.RentalNumber ?? ""));
        }
        return result;
    }

    public async Task<DispatchDto> MarkAsDeliveredAsync(int id)
    {
        var d = await _repo.GetByIdAsync(id)
            ?? throw new KeyNotFoundException($"Despacho ID {id} no encontrado.");
        d.Status = DispatchStatus.Entregado;
        d.UpdatedAt = DateTime.UtcNow;
        await _repo.UpdateAsync(d);
        var rental = await _rentalRepo.GetByIdAsync(d.RentalId);
        return Map(d, rental?.RentalNumber ?? "");
    }

    private static DispatchDto Map(Dispatch d, string rentalNumber) => new(
        d.Id, d.RentalId, rentalNumber,
        d.DispatchedBy?.FullName ?? $"Usuario #{d.DispatchedByUserId}",
        d.DispatchDate, d.Status.ToString(),
        d.TransportPlate, d.DriverName, d.GuideNumber);
}

// ── RECEPTION SERVICE ─────────────────────────────────────────────────────────
public class ReceptionService : IReceptionService
{
    private readonly IReceptionRepository _repo;
    private readonly IDispatchRepository _dispatchRepo;

    public ReceptionService(IReceptionRepository repo, IDispatchRepository dispatchRepo)
    {
        _repo = repo;
        _dispatchRepo = dispatchRepo;
    }

    public async Task<ReceptionDto> CreateAsync(CreateReceptionRequest request, int receivedByUserId)
    {
        if (await _repo.GetByDispatchAsync(request.DispatchId) is not null)
            throw new InvalidOperationException("Este despacho ya tiene una recepción registrada.");

        var dispatch = await _dispatchRepo.GetByIdAsync(request.DispatchId)
            ?? throw new KeyNotFoundException($"Despacho ID {request.DispatchId} no encontrado.");

        var reception = new Reception
        {
            DispatchId = request.DispatchId,
            ReceivedByUserId = receivedByUserId,
            ReceptionDate = DateTime.UtcNow,
            IsComplete = request.IsComplete,
            MissingItems = request.MissingItems,
            DamagedItems = request.DamagedItems,
            Notes = request.Notes
        };

        dispatch.Status = DispatchStatus.Entregado;
        await _dispatchRepo.UpdateAsync(dispatch);
        await _repo.AddAsync(reception);
        return Map(reception);
    }

    public async Task<ReceptionDto?> GetByDispatchAsync(int dispatchId)
    {
        var r = await _repo.GetByDispatchAsync(dispatchId);
        return r is null ? null : Map(r);
    }

    private static ReceptionDto Map(Reception r) => new(
        r.Id, r.DispatchId,
        r.ReceivedBy?.FullName ?? $"Usuario #{r.ReceivedByUserId}",
        r.ReceptionDate, r.IsComplete, r.MissingItems, r.DamagedItems);
}

// ── INSPECTION SERVICE ────────────────────────────────────────────────────────
public class InspectionService : IInspectionService
{
    private readonly IInspectionRepository _repo;
    private readonly IScaffoldingRepository _scaffoldingRepo;

    public InspectionService(IInspectionRepository repo, IScaffoldingRepository scaffoldingRepo)
    {
        _repo = repo;
        _scaffoldingRepo = scaffoldingRepo;
    }

    public async Task<InspectionDto> CreateAsync(CreateInspectionRequest request, int inspectorUserId)
    {
        var scaffolding = await _scaffoldingRepo.GetByIdAsync(request.ScaffoldingId)
            ?? throw new KeyNotFoundException($"Andamio ID {request.ScaffoldingId} no encontrado.");

        var inspection = new Inspection
        {
            ScaffoldingId = request.ScaffoldingId,
            InspectorUserId = inspectorUserId,
            InspectionDate = DateTime.UtcNow,
            Result = request.Result,
            Findings = request.Findings,
            Recommendations = request.Recommendations,
            PhotoUrl = request.PhotoUrl,
            RentalId = request.RentalId
        };

        // Si rechazado, poner en mantenimiento
        if (request.Result == InspectionResult.Rechazado)
        {
            scaffolding.Status = ScaffoldingStatus.EnMantenimiento;
            await _scaffoldingRepo.UpdateAsync(scaffolding);
        }

        await _repo.AddAsync(inspection);
        return Map(inspection, scaffolding.Code);
    }

    public async Task<IEnumerable<InspectionDto>> GetByScaffoldingAsync(int scaffoldingId)
    {
        var inspections = await _repo.GetByScaffoldingAsync(scaffoldingId);
        var scaffolding = await _scaffoldingRepo.GetByIdAsync(scaffoldingId);
        return inspections.Select(i => Map(i, scaffolding?.Code ?? ""));
    }

    public async Task<InspectionDto?> GetLastAsync(int scaffoldingId)
    {
        var i = await _repo.GetLastInspectionAsync(scaffoldingId);
        if (i is null) return null;
        var s = await _scaffoldingRepo.GetByIdAsync(scaffoldingId);
        return Map(i, s?.Code ?? "");
    }

    private static InspectionDto Map(Inspection i, string scaffoldingCode) => new(
        i.Id, scaffoldingCode,
        i.Inspector?.FullName ?? $"Inspector #{i.InspectorUserId}",
        i.InspectionDate, i.Result.ToString(),
        i.Findings, i.Recommendations, i.PhotoUrl);
}
