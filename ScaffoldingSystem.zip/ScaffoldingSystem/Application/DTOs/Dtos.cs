using ScaffoldingSystem.Domain.Enums;
using System.ComponentModel.DataAnnotations;

namespace ScaffoldingSystem.Application.DTOs;

// ── AUTH ──────────────────────────────────────────────────────────────────────
public record LoginRequest(
    [Required, EmailAddress] string Email,
    [Required] string Password
);

public record LoginResponse(
    string Token,
    string FullName,
    string Role,
    DateTime Expiration
);

// ── USUARIOS ──────────────────────────────────────────────────────────────────
public record CreateUserRequest(
    [Required, StringLength(100)] string FullName,
    [Required, EmailAddress] string Email,
    [Required, MinLength(8)] string Password,
    string Phone,
    [Required] UserRole Role
);

public record UpdateUserRequest(
    [Required, StringLength(100)] string FullName,
    string Phone
);

public record UserDto(
    int Id,
    string FullName,
    string Email,
    string Phone,
    string Role,
    bool IsActive,
    DateTime CreatedAt
);

// ── ANDAMIOS ──────────────────────────────────────────────────────────────────
public record CreateScaffoldingRequest(
    [Required, StringLength(20)] string Code,
    [Required] string Description,
    [Required] ScaffoldingType Type,
    [Range(0.1, 100)] decimal HeightMeters,
    [Range(1, 10000)] decimal WeightKg,
    string Location,
    string? Notes
);

public record UpdateScaffoldingRequest(
    string Description,
    ScaffoldingStatus Status,
    string Location,
    string? Notes
);

public record ScaffoldingDto(
    int Id,
    string Code,
    string Description,
    string Type,
    string Status,
    decimal HeightMeters,
    decimal WeightKg,
    string Location,
    string? Notes
);

// ── ALQUILERES ────────────────────────────────────────────────────────────────
public record CreateRentalRequest(
    [Required] int ClientUserId,
    [Required] DateTime StartDate,
    [Required] DateTime ExpectedEndDate,
    [Required] string DeliveryAddress,
    string? Observations,
    [Required] List<RentalItemRequest> Items
);

public record RentalItemRequest(
    [Required] int ScaffoldingId,
    [Range(1, 100)] int Quantity,
    [Range(0, 999999)] decimal DailyRate
);

public record RentalDto(
    int Id,
    string RentalNumber,
    string ClientName,
    DateTime StartDate,
    DateTime ExpectedEndDate,
    DateTime? ActualEndDate,
    string Status,
    decimal TotalAmount,
    string DeliveryAddress,
    List<RentalItemDto> Items
);

public record RentalItemDto(
    int ScaffoldingId,
    string ScaffoldingCode,
    int Quantity,
    decimal DailyRate
);

public record UpdateRentalStatusRequest(
    [Required] RentalStatus Status,
    string? Observations
);

// ── DESPACHO ──────────────────────────────────────────────────────────────────
public record CreateDispatchRequest(
    [Required] int RentalId,
    [Required] string TransportPlate,
    [Required] string DriverName,
    string? GuideNumber,
    string? Notes
);

public record DispatchDto(
    int Id,
    int RentalId,
    string RentalNumber,
    string DispatchedBy,
    DateTime DispatchDate,
    string Status,
    string TransportPlate,
    string DriverName,
    string? GuideNumber
);

// ── RECEPCIÓN ─────────────────────────────────────────────────────────────────
public record CreateReceptionRequest(
    [Required] int DispatchId,
    bool IsComplete,
    string? MissingItems,
    string? DamagedItems,
    string? Notes
);

public record ReceptionDto(
    int Id,
    int DispatchId,
    string ReceivedBy,
    DateTime ReceptionDate,
    bool IsComplete,
    string? MissingItems,
    string? DamagedItems
);

// ── INSPECCIONES ──────────────────────────────────────────────────────────────
public record CreateInspectionRequest(
    [Required] int ScaffoldingId,
    [Required] InspectionResult Result,
    [Required] string Findings,
    string? Recommendations,
    string? PhotoUrl,
    int? RentalId
);

public record InspectionDto(
    int Id,
    string ScaffoldingCode,
    string Inspector,
    DateTime InspectionDate,
    string Result,
    string Findings,
    string? Recommendations,
    string? PhotoUrl
);
