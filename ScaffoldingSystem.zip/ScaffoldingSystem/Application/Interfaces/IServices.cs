using ScaffoldingSystem.Application.DTOs;
using ScaffoldingSystem.Domain.Enums;

namespace ScaffoldingSystem.Application.Interfaces;

public interface IAuthService
{
    Task<LoginResponse> LoginAsync(LoginRequest request);
}

public interface IUserService
{
    Task<UserDto> CreateUserAsync(CreateUserRequest request);
    Task<UserDto?> GetByIdAsync(int id);
    Task<IEnumerable<UserDto>> GetAllAsync();
    Task<IEnumerable<UserDto>> GetByRoleAsync(UserRole role);
    Task<UserDto> UpdateAsync(int id, UpdateUserRequest request);
    Task DeactivateAsync(int id);
}

public interface IScaffoldingService
{
    Task<ScaffoldingDto> CreateAsync(CreateScaffoldingRequest request);
    Task<ScaffoldingDto?> GetByIdAsync(int id);
    Task<IEnumerable<ScaffoldingDto>> GetAllAsync();
    Task<IEnumerable<ScaffoldingDto>> GetAvailableAsync();
    Task<ScaffoldingDto> UpdateAsync(int id, UpdateScaffoldingRequest request);
    Task DeleteAsync(int id);
}

public interface IRentalService
{
    Task<RentalDto> CreateAsync(CreateRentalRequest request);
    Task<RentalDto?> GetByIdAsync(int id);
    Task<IEnumerable<RentalDto>> GetAllAsync();
    Task<IEnumerable<RentalDto>> GetByClientAsync(int clientUserId);
    Task<RentalDto> UpdateStatusAsync(int id, UpdateRentalStatusRequest request);
}

public interface IDispatchService
{
    Task<DispatchDto> CreateAsync(CreateDispatchRequest request, int dispatchedByUserId);
    Task<DispatchDto?> GetByIdAsync(int id);
    Task<IEnumerable<DispatchDto>> GetPendingAsync();
    Task<DispatchDto> MarkAsDeliveredAsync(int id);
}

public interface IReceptionService
{
    Task<ReceptionDto> CreateAsync(CreateReceptionRequest request, int receivedByUserId);
    Task<ReceptionDto?> GetByDispatchAsync(int dispatchId);
}

public interface IInspectionService
{
    Task<InspectionDto> CreateAsync(CreateInspectionRequest request, int inspectorUserId);
    Task<IEnumerable<InspectionDto>> GetByScaffoldingAsync(int scaffoldingId);
    Task<InspectionDto?> GetLastAsync(int scaffoldingId);
}
